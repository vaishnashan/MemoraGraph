"""
Wraps Docling to turn PDF/DOCX files into a unified structured document,
then uses Docling's own HybridChunker to split it into embedding-ready
chunks.

Why HybridChunker instead of a plain character-count splitter (e.g. a
generic LangChain RecursiveCharacterTextSplitter):
  - It works directly on the *structured* Docling document, not flattened
    text, so it respects headings, paragraphs, and table boundaries instead
    of cutting mid-sentence or mid-table.
  - It's tokenization-aware: chunk sizes are measured in the actual tokens
    your embedding model will see, not raw character count, so nothing
    silently overflows the embedding model's context window.
  - It auto-merges undersized neighboring chunks that share the same
    heading, so you don't end up with a pile of tiny near-empty chunks.
  - contextualize() prepends the relevant heading/caption context onto each
    chunk's text before embedding, which measurably improves retrieval
    quality for section-heavy documents (lecture notes, reports, specs).

SPEED NOTES:
  - The very first call downloads Docling's ML models (layout, OCR, table
    structure — ~1-2GB total) and caches them locally. That first run being
    slow is expected; every run after should be much faster.
  - OCR and table-structure detection are OFF by default here, since most
    uploaded PDFs (reports, notes, exported docs) already have a real text
    layer and don't need OCR at all — this is the single biggest speedup.
    Flip ENABLE_OCR / ENABLE_TABLE_STRUCTURE to True via env vars only for
    scanned/image-based PDFs that actually need it.

Day 2 task: get this working end-to-end on a few sample files before
touching anything else.
"""
import os
from dataclasses import dataclass
from pathlib import Path

from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import PdfPipelineOptions
from docling.document_converter import DocumentConverter, PdfFormatOption
from docling.chunking import HybridChunker
from docling_core.types.doc.document import DoclingDocument
from transformers import AutoTokenizer

from application.models.schemas import Chunk

# Must match the embedding model used downstream in the embeddings module —
# keeping these in lockstep is what makes "tokenization-aware" meaningful.
EMBED_MODEL_ID = "sentence-transformers/all-MiniLM-L6-v2"
MAX_TOKENS = 512  # safe context window for MiniLM-L6-v2

SUPPORTED_EXTENSIONS = {"pdf", "docx"}

# Toggle these via .env only if you're dealing with scanned/image-only PDFs.
# Leave off for normal text-based PDFs/DOCX — this is what makes parsing fast.
ENABLE_OCR = os.environ.get("DOCLING_ENABLE_OCR", "false").lower() == "true"
ENABLE_TABLE_STRUCTURE = os.environ.get("DOCLING_ENABLE_TABLES", "false").lower() == "true"

# Loaded once at import time — reused across every parse/chunk call.
_tokenizer = AutoTokenizer.from_pretrained(EMBED_MODEL_ID)
_chunker = HybridChunker(tokenizer=_tokenizer, max_tokens=MAX_TOKENS, merge_peers=True)

_pdf_options = PdfPipelineOptions()
_pdf_options.do_ocr = ENABLE_OCR
_pdf_options.do_table_structure = ENABLE_TABLE_STRUCTURE
_pdf_options.generate_page_images = False
_pdf_options.generate_picture_images = False

# Built once — building a fresh DocumentConverter (and reloading its models)
# on every single upload is itself a major slowdown.
_converter = DocumentConverter(
    format_options={
        InputFormat.PDF: PdfFormatOption(pipeline_options=_pdf_options),
    }
)


@dataclass
class ParsedDocument:
    doc_id: str
    filename: str
    file_type: str
    docling_document: DoclingDocument
    full_text: str  # markdown export — handy for debugging/preview, not for embedding


def parse_document(file_path: str, doc_id: str) -> ParsedDocument:
    """Parse a PDF or DOCX file into a unified, structure-preserving Docling document."""
    path = Path(file_path)
    file_type = path.suffix.lower().lstrip(".")

    if file_type not in SUPPORTED_EXTENSIONS:
        raise ValueError(
            f"Unsupported file type '.{file_type}'. Supported: {sorted(SUPPORTED_EXTENSIONS)}"
        )

    result = _converter.convert(file_path)
    docling_doc = result.document

    # Markdown export is just for humans/debugging — actual chunk text for
    # embedding comes from chunk_document() below via contextualize().
    full_text = docling_doc.export_to_markdown()

    return ParsedDocument(
        doc_id=doc_id,
        filename=path.name,
        file_type=file_type,
        docling_document=docling_doc,
        full_text=full_text,
    )


def chunk_document(parsed: ParsedDocument) -> list[Chunk]:
    """
    Structure-aware, tokenization-aware chunking using Docling's HybridChunker.
    Returns a list of Chunk objects (from app.models.schemas) ready to be
    embedded and indexed.
    """
    chunk_iter = _chunker.chunk(dl_doc=parsed.docling_document)

    chunks: list[Chunk] = []
    for i, raw_chunk in enumerate(chunk_iter):
        # contextualize() prepends the chunk's heading/caption trail so the
        # embedded text carries structural context — always use this over
        # raw_chunk.text when generating embeddings.
        text = _chunker.contextualize(chunk=raw_chunk)
        chunks.append(Chunk(
            chunk_id=f"{parsed.doc_id}_chunk_{i}",
            doc_id=parsed.doc_id,
            text=text,
            chunk_index=i,
        ))

    return chunks


def parse_and_chunk(file_path: str, doc_id: str) -> tuple[ParsedDocument, list[Chunk]]:
    """Convenience wrapper: parse then chunk in one call — what upload.py should use."""
    parsed = parse_document(file_path, doc_id)
    chunks = chunk_document(parsed)
    return parsed, chunks